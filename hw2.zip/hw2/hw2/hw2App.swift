//
//  hw2App.swift
//  hw2
//
//  Created by 陳昰佑 on 2025/9/19.
//

import SwiftUI

@main
struct hw2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
