// 2025.09.21 21:57 Done
// 陳昰佑


import SwiftUI

// 貓右耳的形狀
struct RightEar: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let startPoint = CGPoint(x: 44, y: 14)
        let controlPoint = CGPoint(x: 59.8, y: -30.0)
        let endPoint = CGPoint(x: 82, y: 14)

        path.move(to: startPoint)
        path.addQuadCurve(to: endPoint, control: controlPoint)
        
        return path
    }
}

// 貓右耳的形狀
struct LeftEar: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let startPoint = CGPoint(x: 80, y: 25)
        let controlPoint = CGPoint(x: 100.8, y: -40.0)
        let endPoint = CGPoint(x: 130.8, y: 25)

        path.move(to: startPoint)
        path.addQuadCurve(to: endPoint, control: controlPoint)
        
        return path
    }
}

// 貓嘴巴的形狀
struct MouthShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addQuadCurve(to: CGPoint(x: rect.midX, y: rect.maxY), control: CGPoint(x: rect.minX * 0.8, y: rect.maxY))
        path.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.midY), control: CGPoint(x: rect.midX * 1.2, y: rect.maxY))
        return path
    }
}

// 左1腳的形狀
struct LegLeftFirst: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let startPoint = CGPoint(x: 96, y: 203.5)
        let controlPoint = CGPoint(x: 105.4, y: 238.4)
        let endPoint = CGPoint(x: 122.3, y: 212.5)

        path.move(to: startPoint)
        path.addQuadCurve(to: endPoint, control: controlPoint)
        
        return path

    }
}

// 其他腳的形狀
struct LegOthers: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let startPoint = CGPoint(x: 97.3, y: 224.1)
        let controlPoint = CGPoint(x: 108.4, y: 250.2)
        let endPoint = CGPoint(x: 112.7, y: 224.1)

        path.move(to: startPoint)
        path.addQuadCurve(to: endPoint, control: controlPoint)
        
        return path

    }
}

// 底部虛線線條
struct HorizontalLineShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        return path
    }
}

// 尾巴曲線
struct Tail: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()

        let startPoint = CGPoint(x: 92.3, y: 129.8)
        let controlPoint1 = CGPoint(x: 185.1, y: 120.8)
        let midPoint = CGPoint(x: 159.6, y: 180.1)

        let controlPoint2 = CGPoint(x: 142.9, y: 220.9)
        let endPoint = CGPoint(x: 73.7, y: 217.3)

        path.move(to: startPoint)
        path.addQuadCurve(to: midPoint, control: controlPoint1)
        path.addQuadCurve(to: endPoint, control: controlPoint2)
        
        return path
    }
}

// 背上條紋
struct Stripes: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        let startPoint = CGPoint(x: 136.6, y: 150.6)
        let controlPoint = CGPoint(x: 143.4, y: 180.9)
        let endPoint = CGPoint(x: 150.2, y: 150.6)

        path.move(to: startPoint)
        path.addQuadCurve(to: endPoint, control: controlPoint)
        
        return path
    }
}






struct ContentView: View {
    var body: some View {

        ZStack {
            
            // 腳1
            ZStack {
                LegLeftFirst()
                    .offset(x:-30, y:198)
                    .stroke(Color.black, lineWidth: 3.5)
                LegLeftFirst()
                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                    .scaleEffect(0.35)
                    .offset(x:-90, y:100)
            }

            // 身體
            ZStack {
                Capsule()
                    .trim(from: 0, to: 1)
                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                    .frame(width: 300, height: 90)
                Capsule()
                    .trim(from: 0.75, to: 0.92)
                    .stroke(Color.black, lineWidth: 4)
                    .offset(x: -47, y:4)
                Circle()
                    .trim(from: 0.25, to: 0.715)
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 90, height: 88)
                    .offset(x:-108)
                Tail()
                    .stroke(Color.black, lineWidth: 4)
                    .offset(x:215, y:-125)
                Tail()
                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                    .scaleEffect(0.935)
                    .offset(x:210.5, y:-117.65)
                    
            }
            .frame(width: 400, height: 100)
            
            // 其他腳
            HStack(spacing: -200) {
                            ForEach(0..<5) { _ in
                                LegOthers()
                                    .stroke(Color.black, lineWidth: 3.7)
                                    .offset(x: 15, y: 189.4)
                                LegOthers()
                                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                                    .offset(x: -92, y: 187)
                                Rectangle()
                                            .fill(Color.black)
                                            .frame(width: 27, height: 3.7)
                                            .offset(x:-126 ,y:44)
                            }
                        }
            
            // 背上條紋
            HStack(spacing: -200) {
                ForEach(0..<6) { index in
                    Stripes()
                        .fill(Color(red: 72/255, green: 150/255, blue: 238/255))
                        .offset(x: 25, y: 225)
                        .scaleEffect(pow(0.98, CGFloat(index)))
                }
            }
            .offset(x: 10, y: -46.6)
            
            // 頭部
            ZStack {
                // 右耳 (外框)
                RightEar()
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 19, height: 14)
                    .offset(x: -28, y: -51)
                // 左耳 (外框)
                LeftEar()
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 19, height: 14)
                    .offset(x: -28, y: -51)

                // 右耳 (填滿)
                RightEar()
                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                    .frame(width: 31, height: 20)
                    .scaleEffect(0.91)
                    .offset(x: -18, y: -47)
                // 左耳 (填滿)
                LeftEar()
                    .fill(Color(red: 181/255, green: 226/255, blue: 255/255))
                    .frame(width: 31, height: 20)
                    .offset(x: -22, y: -46)
                // 眼睛
                Ellipse()
                    .fill(Color.black)
                    .frame(width: 15, height: 20)
                    .offset(x:28, y: 5)
                    .rotationEffect(.degrees(-10))
                // 嘴巴
                MouthShape()
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 15, height: 9)
                    .offset(x: -11, y: -1)
                MouthShape()
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 15, height: 9)
                    .offset(x: -3, y: -1)
                    .scaleEffect(x: -1)
                
            }
            .offset(x: -125)
        }
        .padding()
        .background(Color.white)
    }
}

#Preview {
    ContentView()
}

