//
//  hw2Tests.swift
//  hw2Tests
//
//  Created by 陳昰佑 on 2025/9/19.
//

import Testing
@testable import hw2

struct hw2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
